# Reflection Brief — Harness Engineering Capstone

**Name:** Himansu Bhamidipati  
**Date:** 2026-10-10

## Environment

- **System 1 model:** Claude Haiku 4.5 (`claude-haiku-4-5-20251001`)
- **OS / Python recorded in the System 1 summary:** Linux; the captured pytest environment reports Python 3.13
- **System 1 batch cost:** $0.1305 USD (`evidence/system1_agentic_loop/summary.md`)

---

## Part 1 — Per-system

### System 1 — Agentic loop

**1. Loop control.**  
The trace `evidence/system1_agentic_loop/claim_08_minor_porch_damage.jsonl` records five turns. Its `stop_reason` values are `tool_use`, `tool_use`, `tool_use`, `tool_use`, and `end_turn`; the first four turns make tool calls and the fifth does not. The control logic therefore keeps the loop moving while the API asks for tool use and exits when the response reports `end_turn`, which is the behavior visible in that trace.

**2. Anti-pattern.**  
The anti-pattern suite checks for using assistant-message text as the mechanism for deciding what the loop should do; this is covered by `evidence/system1_agentic_loop/pytest_S1.log`, where `tests/test_antipatterns.py` passes. If the implementation depended on phrases in generated text, a wording change could send the loop down the wrong branch even when the API had already supplied a precise structured signal such as `tool_use` or `end_turn`. Using the structured response field is therefore more stable than interpreting prose as a control protocol.

**3. Tool design.**  
`lookup_policy` and the claim-routing tools can all appear during the same claim-processing flow, so their descriptions need to make their individual purposes explicit. The tool behavior is part of the System 1 checks recorded in `evidence/system1_agentic_loop/pytest_S1.log`; the passing tool tests support keeping the interface structured rather than relying on free-form text. A structured error is useful because the next step can distinguish a missing field or invalid value from an ordinary textual message and construct a corrected call instead of guessing.

**4. Your numbers.**  
The row for `claim_08_minor_porch_damage` in `evidence/system1_agentic_loop/summary.md` reports 5 turns, 18,546 input tokens, 910 output tokens, a total of 19,456 tokens, and an estimated cost of $0.0231. The trace `claim_08_minor_porch_damage.jsonl` also contains the five individual turns behind those totals. These numbers are run-specific rather than a fixed template value, so differences from a README example are expected when the actual tool sequence or generated response lengths differ.

### System 2 — Context strategy

**5. The reduction.**  
`evidence/system2_context_strategy/budget.json` gives a baseline of 38,708 tokens and an assembled context of 16,824 tokens, a 56.54% reduction. The `active` section is by far the largest part at 15,789 tokens. It remains byte-exact because it represents the current issue, where changing wording or dropping a small detail can change the answer to a live question.

**6. Summarize vs preserve.**  
The budget separates older resolved material from the active case instead of treating every part of the transcript equally. In `budget.json`, `resolved_refund` uses 394 tokens and `resolved_subscription` uses 455, while `active` uses 15,789 tokens. The practical rule is to compress information that is no longer central to the current turn and retain the active material with its original detail when exact facts may still be queried.

**7. Facts block.**  
The comparison between `evidence/system2_context_strategy/eval.jsonl` and `eval_control.jsonl` shows the important regression in the **control** run: Q6 fails in `eval_control.jsonl`, while Q6 passes in the engineered `eval.jsonl`. The control answer cannot provide the exact `in_progress` token, whereas the engineered context returns it directly. This demonstrates why a small structured facts block can protect critical fields even when the surrounding history is compressed.

### System 3 — Claude Code config

**8. Path-scoped rules.**  
`evidence/system3_claude_config/evidence_rule_api.md` uses the frontmatter `paths: - "src/api/**/*"`. That rule is activated only for matching API files, while a broad `CLAUDE.md` rule would be available more generally. The path filter therefore keeps API-specific instructions from becoming irrelevant context for unrelated React or test work.

**9. Forked skill.**  
In `evidence/system3_claude_config/evidence_rule_skill.md`, the relevant frontmatter is `context: fork` plus an `allowed-tools` list containing read-oriented tools such as `Read`, `Grep`, and `Glob`, along with restricted Git/GitHub commands. The fork keeps the verbose deployment-check investigation separate from the parent session, and the allowlist prevents the skill from gaining write or deploy capabilities. The file itself also states that `/deploy-check` is read-only, so the safety boundary is both configured and documented.

**10. Scope.**  
The scope distinction is documented in `evidence/system3_claude_config/evidence_rule_claude.md`. Project-level configuration includes files such as `.claude/rules/api.md` and `.claude/skills/deploy-check/SKILL.md`, while user-level configuration is described under `~/.claude/`. The captured `evidence/system3_claude_config/claude_dir_structure.txt` confirms the project-side `.claude` layout used by this submission.

### System 4 — Orchestration

**11. Push work down.**  
The System 4 test log names the indexed path through `test_defects_since_uses_index_and_does_not_load_full_table`, and the corresponding lookup is the `defects_since` query over the warm store. `evidence/system4_orchestration/shift_run_output.txt` reports 0 new defects for Shift C and then summarizes 3 high plus 2 medium defects, with one repeated low-severity issue. Because the database performs the filtering before the model is called, the model receives the small result set rather than the complete warm-tier history.

**12. Crash recovery.**  
`evidence/system4_orchestration/pytest_S4.log` records the recovery truth-table tests and explicitly shows `test_threshold_constant_is_30_minutes` passing. The same log shows fresh recovery for stale or incomplete state and resume for recent complete state. Starting a new run with a compact summary can therefore discard damaged or stale conversational state while retaining the information needed to continue safely.

**13. Small state.**  
`evidence/system4_orchestration/hot_state_size.txt` reports a `hot_state.json` size of 643 bytes. A small fixed-size state payload matters even when the job runs once per shift because the number of shifts is unbounded, so carrying an ever-growing transcript would eventually increase storage, context, and processing cost. Keeping only the hot information makes each new shift independent of the full historical volume.

---

## Part 2 — Synthesis

**14. Three layers.**  
The **Model** layer is visible in `evidence/system1_agentic_loop/claim_08_minor_porch_damage.jsonl`, where the Claude response selects tools and eventually returns `end_turn`. The **Harness** layer is represented by `evidence/system2_context_strategy/budget.json`, where the application decides how much conversation material reaches the model. The **Orchestration** layer appears in `evidence/system4_orchestration/shift_run_output.txt` and `hot_state_size.txt`, where work and state are carried between scheduled shift executions rather than being confined to one model turn.

**15. Deterministic vs prompt.**  
A deterministic enforcement point is the System 4 recovery policy: `evidence/system4_orchestration/pytest_S4.log` verifies the 30-minute threshold and the resume/fresh truth table. A prompt-guided behavior is the model's selection of the next tool in the System 1 trace `claim_08_minor_porch_damage.jsonl`. Hard rules belong in code when violating them would be unsafe or expensive; model guidance is better for interpreting language and choosing among valid actions when the input is ambiguous.

**16. Context, two faces.**  
System 2 manages context inside one conversation: `budget.json` reduces 38,708 baseline tokens to 16,824 assembled tokens. System 4 handles context across separate shift executions by keeping the hot state to 643 bytes, as recorded in `hot_state_size.txt`. Both approaches prevent historical information from growing without bound, but System 2 performs selective compression while System 4 serializes a compact state between runs.

**17. Reliability you cannot see in one run.**  
`evidence/system4_orchestration/pytest_S4.log` contains multiple recovery cases, including the boundary cases for recent versus stale state. A single successful shift would not show whether the implementation makes the correct choice at the recovery boundary. Testing the truth table before shipping matters because a rare crash or partial write can otherwise turn into an incorrect resume decision in production.

**18. Blast radius.**  
For System 1, the model's operational reach is limited to the tools exposed in the claims harness, as demonstrated by the tool calls in `claim_08_minor_porch_damage.jsonl`. The run does not give the model arbitrary shell or database access; it can only request the defined claim-processing operations. The loop's bounded execution is the practical circuit breaker, while `evidence/system1_agentic_loop/pytest_S1.log` shows the loop and tool suites passing their checks.

---

## Part 3 — Honest assessment

**19. What broke.**  
I do not have a first-attempt failure log in the submitted evidence, so I would not invent one just to make this section look more complete. What I can verify is that the `evidence/system1_agentic_loop/pytest_S1.log` ends with 29 passing tests, `evidence/system2_context_strategy/pytest_S2.log` with 30, `evidence/system3_claude_config/pytest_S3.log` with 35, and `evidence/system4_orchestration/pytest_S4.log` with 33. I checked those logs rather than claiming a setup failure that is not preserved in the submission.

**20. What I would change.**  
I would change System 4's local-state design before using it as a distributed service. `hot_state_size.txt` shows that the current hot state is only 643 bytes, which is excellent for a local single-process workflow but does not solve concurrent access across multiple workers. For a cloud deployment, I would move hot state to a shared transactional or in-memory store and keep the warm history in a managed database, while preserving the same bounded-state principle verified by `pytest_S4.log`.

---

## Submission evidence check

- System 1 evidence folder present: `evidence/system1_agentic_loop/`
- System 2 evidence folder present: `evidence/system2_context_strategy/`
- System 3 evidence folder present: `evidence/system3_claude_config/`
- System 4 evidence folder present: `evidence/system4_orchestration/`
- Reflection completed with an artifact reference in every answer.
- The four captured pytest logs report **29 + 30 + 35 + 33** passing tests respectively. The assignment screenshot expects System 1 to total 30 tests, but the submitted `pytest_S1.log` contains 29 collected and 29 passed; this has been left unchanged because changing a recorded test log would falsify the run evidence.

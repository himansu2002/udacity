# Run summary — 20260924_124800

- Model: `claude-haiku-4-5-20251001`
- Fixtures processed: 8
- Estimated total cost: **$0.1305** USD

| claim_id | outcome | claim_type | severity | turns | clarifications_asked | input_tokens | output_tokens | est_cost_usd | elapsed_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| claim_01_kitchen_fire | incomplete | - | - | 3 | 0 | 9277 | 430 | 0.0114 | 7.3 |
| claim_02_stolen_bike | incomplete | - | - | 2 | 0 | 6158 | 422 | 0.0083 | 4.2 |
| claim_03_water_damage | routed | property_damage | high | 5 | 1 | 18769 | 1213 | 0.0248 | 13.4 |
| claim_04_neighbor_injury | routed | liability | high | 4 | 0 | 14366 | 926 | 0.019 | 12.6 |
| claim_05_auto_collision | routed | auto | high | 4 | 0 | 14869 | 916 | 0.0194 | 9.7 |
| claim_06_low_confidence_escalation | incomplete | - | - | 3 | 0 | 9552 | 619 | 0.0126 | 8.4 |
| claim_07_tree_falls_on_car | incomplete | - | - | 3 | 0 | 9273 | 509 | 0.0118 | 7.1 |
| claim_08_minor_porch_damage | routed | property_damage | low | 5 | 0 | 18546 | 910 | 0.0231 | 14.4 |
